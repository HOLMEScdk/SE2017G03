class user_login:
    def __init__(self, ID,):
        self.name = ID
