from django.apps import AppConfig


class SeWorkConfig(AppConfig):
    name = 'se_work'
